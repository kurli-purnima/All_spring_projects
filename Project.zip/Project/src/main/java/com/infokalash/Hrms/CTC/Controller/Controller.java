package com.infokalash.Hrms.CTC.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infokalash.Hrms.CTC.Configuration.Address;
import com.infokalash.Hrms.CTC.Configuration.Person;

@RestController
public class Controller {
	
	private final Person person;
	
	
	@Autowired
	public Controller(Person person) {
		this.person = person;
	}



	@PostMapping("/")
	public String addPerson() {
	        System.out.println("Received person information:");
	        System.out.println("Name: " + person.getName());
	        System.out.println("Age: " + person.getAge());
	        System.out.println("Email: " + person.getEmail());

	        List<Address> addresses = person.getAddress();
	        for (Address address : addresses) {
	        	System.out.println("\tAddress: " +" ID " +address.getId() +" "
	        			 + address.getStreet()
	                     + ", " + address.getCity()
	                     + ", " + address.getState());
//	            System.out.println("\tAddress ID: " + address.getId());
//	            System.out.println("Street: " + address.getStreet());
//	            System.out.println("City: " + address.getCity());
//	            System.out.println("State: " + address.getState());
//	            System.out.println("Postal Code: " + address.getPostalCode());
	        }
		
		return "Person added successfully ";
	}

}
