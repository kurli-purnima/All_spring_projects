package com.infokalash.Hrms.CTC;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FrameworkCodeApplicationTests {

	@Test
	void contextLoads() {
	}

}
