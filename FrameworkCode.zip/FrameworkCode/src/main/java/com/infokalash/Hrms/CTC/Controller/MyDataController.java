package com.infokalash.Hrms.CTC.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.infokalash.Hrms.CTC.model.MyData;
import com.infokalash.Hrms.CTC.service.MyDataService;

@RestController
public class MyDataController {

    private final MyDataService myDataService;

    @Autowired
    public MyDataController(MyDataService myDataService) {
        this.myDataService = myDataService;
    }

    // Endpoint to add data to MongoDB
    @PostMapping("/api/mydata")
    public MyData addDataToMongoDB(@RequestBody MyData myData) {
        return myDataService.saveData(myData);
    }
}

