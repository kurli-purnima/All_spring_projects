package com.infokalash.Hrms.CTC.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infokalash.Hrms.CTC.Dao.MyDataDao;
import com.infokalash.Hrms.CTC.model.MyData;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MyDataService {

    private final MyDataDao myDataDao;

    @Autowired
    public MyDataService(MyDataDao myDataDao) {
        this.myDataDao = myDataDao;
    }

    public MyData saveData(MyData myData) {
        return myDataDao.save(myData);
    }
}


