package com.infokalash.Hrms.CTC;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;



@SpringBootApplication
public class OutlookMailSenderApplication {


//	@Autowired
//	private EmailSenderService service;
	
	public static void main(String[] args) {
		SpringApplication.run(OutlookMailSenderApplication.class, args);
	}
	
////	@EventListener(ApplicationReadyEvent.class)
//	public void triggerMail( ) {
//		service.sendSimpleEmail("c.chetan@infokalash.com", " This is the email body", " this is the email subject");
//		
//	
//
//}

}
