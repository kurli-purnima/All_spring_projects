package com.infokalash.Hrms.CTC.Model;

public class EmailMessage {
    private EmailAddress to;
    private String subject;
    private ItemBody body;

    public EmailMessage(String emailAddress, String subject, String bodyContent) {
        this.to = new EmailAddress(emailAddress);
        this.subject = subject;
        this.body = new ItemBody(bodyContent);
    }

	public EmailAddress getTo() {
		return to;
	}

	public void setTo(EmailAddress to) {
		this.to = to;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public ItemBody getBody() {
		return body;
	}

	public void setBody(ItemBody body) {
		this.body = body;
	}

   
}


