package com.infokalash.Hrms.CTC.Controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import com.infokalash.Hrms.CTC.Model.EmailMessage;
import com.infokalash.Hrms.CTC.Model.EmailRequest;

@RestController
public class EmailController {

    @Value("${spring.security.oauth2.client.registration.azure.client-id}")
    private String clientId;

    @Value("${spring.security.oauth2.client.registration.azure.client-secret}")
    private String clientSecret;

    @PostMapping("/send-email")
    public ResponseEntity<String> sendEmail(@RequestBody EmailRequest emailRequest) {
        try {
            String accessToken = getAccessToken();

            if (accessToken == null) {
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to obtain access token.");
            }

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set("Authorization", "Bearer " + accessToken);

            EmailMessage emailMessage = new EmailMessage(emailRequest.getRecipientEmail(), emailRequest.getSubject(), emailRequest.getBody());
            HttpEntity<EmailMessage> requestEntity = new HttpEntity<>(emailMessage, headers);

            RestTemplate restTemplate = new RestTemplate();
            ResponseEntity<String> response = restTemplate.exchange("https://graph.microsoft.com/v1.0/me/sendMail", HttpMethod.POST, requestEntity, String.class);

            if (response.getStatusCode().is2xxSuccessful()) {
                return ResponseEntity.ok("Email sent successfully.");
            } else {
                return ResponseEntity.status(response.getStatusCode()).body("Failed to send the email.");
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("An error occurred: " + e.getMessage());
        }
    }

    private String getAccessToken() {
        // Implement your logic to obtain the access token using clientId and clientSecret.
        // You can use OAuth2 flows such as Authorization Code or Client Credentials Grant flow.
        // For simplicity, I'll leave the implementation of this method to you.
        return null;
    }
}
