package com.infokalash.Hrms.CTC.Repository;

import java.util.List;
import java.util.Map;

public interface GenericMongoRepository {
	void save(String collectionName, Map<String, Object> document);
    List<Map<String, Object>> findAll(String collectionName);
    // Define other CRUD methods as needed
}
