package com.infokalash.Hrms.CTC.Service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infokalash.Hrms.CTC.Repository.GenericMongoRepositoryImpl;


@Service
public class GenericMongoService {
    private final GenericMongoRepositoryImpl genericMongoRepository;

    @Autowired
    public GenericMongoService(GenericMongoRepositoryImpl genericMongoRepository) {
        this.genericMongoRepository = genericMongoRepository;
    }

    public void saveDocument(String collectionName, Map<String, Object> document) {
        genericMongoRepository.save(collectionName, document);
    }

//    public List<Map> findAllDocuments(String collectionName) {
//        return genericMongoRepository.findAll(collectionName);
//    }
//    
    // Define other CRUD methods here
}
