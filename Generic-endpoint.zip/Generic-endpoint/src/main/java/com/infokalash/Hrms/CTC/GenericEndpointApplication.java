package com.infokalash.Hrms.CTC;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GenericEndpointApplication {

	public static void main(String[] args) {
		SpringApplication.run(GenericEndpointApplication.class, args);
	}

}
