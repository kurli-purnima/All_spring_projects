package com.infokalash.Hrms.CTC.Repository;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;

public class GenericMongoRepositoryImpl implements GenericMongoRepository{

	private MongoTemplate mongoTemplate;

    @Autowired
    public void GenericMongoRepositoryImpl(MongoTemplate mongoTemplate) {
        this.mongoTemplate = mongoTemplate;
    }

	@Override
	public void save(String collectionName, Map<String, Object> document) {
		// TODO Auto-generated method stub
		mongoTemplate.save(document, collectionName);
	}

	@Override
	public List<Map<String, Object>> findAll(String collectionName) {
		// TODO Auto-generated method stub
		return null;
	}

//	@Override
//	public List<Map<String, Object>> findAll(String collectionName) {
//		// TODO Auto-generated method stub
//		return mongoTemplate.findAll(Map.class, collectionName);
//	}

    

	
	

}
