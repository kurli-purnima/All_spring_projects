package com.infokalash.Hrms.CTC.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infokalash.Hrms.CTC.Service.GenericMongoService;

@RestController
@RequestMapping("/api/generic")
public class GenericController {
    private  GenericMongoService genericMongoService;

//    @Autowired
//    public void GenericMongoController(GenericMongoService genericMongoService) {
//        this.genericMongoService = genericMongoService;
//    }

    @PostMapping("/{collectionName}")
    public ResponseEntity<String> saveDocument(@PathVariable String collectionName,@RequestBody Map<String, Object> document) {
        genericMongoService.saveDocument(collectionName, document);
        return ResponseEntity.ok("Document saved successfully");
    }

//    @GetMapping("/{collectionName}")
//    public ResponseEntity<List<Map>> findAllDocuments(
//            @PathVariable String collectionName) {
//        List<Map> documents = genericMongoService.findAllDocuments(collectionName);
//        return ResponseEntity.ok(documents);
//    }
    
    // Define other CRUD endpoints here
}
