package com.infokalash.Hrms.CTC.Config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.HashMap;
import java.util.Map;

@Configuration
@ConfigurationProperties(prefix = "mongodb")
public class MongoDBConfiguration {
    private Map<String, String> models = new HashMap<>();

	public Map<String, String> getModels() {
		return models;
	}

	public void setModels(Map<String, String> models) {
		this.models = models;
	}

  
}
