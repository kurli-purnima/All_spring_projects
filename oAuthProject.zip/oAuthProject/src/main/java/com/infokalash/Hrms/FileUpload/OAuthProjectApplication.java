package com.infokalash.Hrms.FileUpload;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OAuthProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(OAuthProjectApplication.class, args);
	}

}
