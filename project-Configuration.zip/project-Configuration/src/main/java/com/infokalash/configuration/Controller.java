package com.infokalash.configuration;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
@RestController
public class Controller {
//	
//	@Autowired
	private Person person; 

	@PostMapping("/per")
	public String addPerson() {
		
		Person person=new Person();
		System.out.println(person.getName());
		return "sucess";

}
}
