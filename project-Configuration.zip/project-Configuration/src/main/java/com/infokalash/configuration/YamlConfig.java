//package com.infokalash.configuration;
//
//import org.springframework.boot.context.properties.ConfigurationProperties;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.context.annotation.PropertySource;
//import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
//
//@Configuration
//@PropertySource(value = "C:\\Users\\ADMIN\\Documents\\springboot\\project-Configuration\\src\\main\\resources\\application.yml")
//public class YamlConfig {
//
//    @Bean
//    @ConfigurationProperties(prefix = "person1")
//    public Person person1() {
//        return new Person();
//    }
//
//    @Bean
//    @ConfigurationProperties(prefix = "person2")
//    public Person person2() {
//        return new Person();
//    }
//
//    @Bean
//    public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
//        return new PropertySourcesPlaceholderConfigurer();
//    }
//}
