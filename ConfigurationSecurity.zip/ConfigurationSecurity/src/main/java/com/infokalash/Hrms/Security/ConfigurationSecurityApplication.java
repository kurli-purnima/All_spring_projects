package com.infokalash.Hrms.Security;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConfigurationSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConfigurationSecurityApplication.class, args);
	}

}
