package com.infokalash.Hrms.Security.Controller;
import java.security.Principal;

import org.springframework.security.oauth2.client.OAuth2AuthorizedClient;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class AuthController {

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @GetMapping("/oauth2/callback/google")
    public String googleCallback() {
        // Handle the callback from Google
        return "redirect:/"; // Redirect to the home page or any other desired page
    }
    
    
    @GetMapping("/user")
	public Principal user(Principal principal) {
		 System.out.println("username"+ principal.getName());
		 return principal;
	 }

}
