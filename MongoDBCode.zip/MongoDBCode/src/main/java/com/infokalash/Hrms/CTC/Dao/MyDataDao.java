package com.infokalash.Hrms.CTC.Dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Component;

import com.infokalash.Hrms.CTC.model.MyData;

@Configuration
public class MyDataDao {

    private final MongoTemplate mongoTemplate;

    @Autowired
    public MyDataDao(MongoTemplate mongoTemplate) {
        this.mongoTemplate = mongoTemplate;
    }

    public MyData save(MyData myData) {
        return mongoTemplate.save(myData);
    }
}
