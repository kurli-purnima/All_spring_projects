package com.infokalash.Hrms.CTC.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


@Document(collection = "mydata")
public class MyData {

   
    private String name;
  
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public MyData(String name) {
		super();
		this.name = name;
	}	

    // Constructors, getters, and setters
	
    
}
