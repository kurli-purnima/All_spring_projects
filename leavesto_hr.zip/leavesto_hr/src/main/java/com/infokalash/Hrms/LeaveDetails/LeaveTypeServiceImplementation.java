package com.infokalash.Hrms.LeaveDetails;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


//import com.infokalash.Hrms.LeaveDetails.Model.LeaveTypeModel;
//import com.infokalash.Hrms.LeaveDetails.Repository.LeaveTypeRepository;

@Service
public class LeaveTypeServiceImplementation implements LeaveTypeService {
	
	@Autowired
	private LeaveTypeRepository leaveTypeRepo;

	public LeaveTypeServiceImplementation(LeaveTypeRepository leaveTypeRepo) {
		super();
		this.leaveTypeRepo = leaveTypeRepo;
	}

	@Override
	public LeaveTypeModel insert(LeaveTypeModel leave) {
			leave.setApprovedStatus("pending");
			return leaveTypeRepo.save(leave);
	}

	@Override
	public List<LeaveTypeModel> getAllLeaves() {
		List<LeaveTypeModel> leave=leaveTypeRepo.findAll();
		return leave;
	}

	@Override
	public Optional<LeaveTypeModel> getByleaveId(Long leaveId) {
		Optional<LeaveTypeModel> leavebyid=leaveTypeRepo.findById(leaveId);
		return leavebyid;
	}

	@Override
	public List<LeaveTypeModel> getLeaveByemployeeId(Long empid) {
		List<LeaveTypeModel> leavetype=leaveTypeRepo.findByempid(empid);
	return leavetype;
	}
	
	@Override
	public List<LeaveTypeModel> getByLeaveType(String LeaveType) {
		List<LeaveTypeModel> leavetype=leaveTypeRepo.findByleaveType(LeaveType);
		return  leavetype;
	}

	
	@Override
	public LeaveTypeModel updateLeave(Long leaveId, LeaveTypeModel leave) {
		LeaveTypeModel leavetype=leaveTypeRepo.findById(leaveId).orElseThrow();
		
		
		if(leavetype!=null) {
			leavetype.setEmpid(leave.getEmpid());
			leavetype.setEndDate(leave.getEndDate());
			leavetype.setStartDate(leave.getStartDate());
			//leavetype.setApprovedBy(leave.getApprovedBy());
			leavetype.setRaisedBy(leave.getRaisedBy());
			leavetype.setNumOfDays(leave.getNumOfDays());
			leavetype.setReason(leave.getReason());
			leavetype.setLeaveType(leave.getLeaveType());
			
		}
		return leaveTypeRepo.save(leavetype);
	}

	@Override
	public void deleteLeave(Long leaveId) {
		LeaveTypeModel leave=leaveTypeRepo.findById(leaveId).orElseThrow();
		
		if(leave!=null) {
			 leaveTypeRepo.delete(leave);
		}
	}

	
	@Override
	public List<LeaveTypeModel> findByempId(Long empid) {
		List<LeaveTypeModel> leavemodel=leaveTypeRepo.searchByempid(empid);
		return leavemodel;
	}

}
