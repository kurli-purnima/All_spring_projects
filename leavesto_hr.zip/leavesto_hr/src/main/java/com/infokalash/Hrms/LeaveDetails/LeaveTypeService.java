package com.infokalash.Hrms.LeaveDetails;

import java.util.List;
import java.util.Optional;



//import com.infokalash.Hrms.LeaveDetails.Model.LeaveTypeModel;

public interface LeaveTypeService {
	
	//Interface to create or insert new leavetype
	 public LeaveTypeModel insert(LeaveTypeModel leave);
	
	 //Interface to get all leave types
	 public List<LeaveTypeModel> getAllLeaves();
	
	 //Interface to get leave type by leave id
	 public Optional<LeaveTypeModel> getByleaveId(Long leaveId);
	 
	 //Interface to get leave type by employee id
	 public List<LeaveTypeModel> getLeaveByemployeeId(Long empid);
	 
	 //Interface to get leave record by leave Type
	 public List<LeaveTypeModel> getByLeaveType(String LeaveType);
	 
	 //inteface to update leavetype by leave id
	 public LeaveTypeModel updateLeave(Long leaveId,LeaveTypeModel leave);
	 
	 //Interface to delete leave type by leave id
	 public void deleteLeave(Long leaveId);
	 
	 //Interface to search the leave type by employee ID
	 public List<LeaveTypeModel> findByempId(Long empid);
	 
	 
	
}
