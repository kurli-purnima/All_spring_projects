package com.infokalash.Hrms.LeaveDetails;

import java.sql.Date;
import java.time.LocalDate;


import com.infokalash.Employee.Model.Employee;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;


@Entity
@Table(name="leave_Type")
public class LeaveTypeModel {
	
	@Id
	//@SequenceGenerator(name = "leaveid", initialValue = 1111, allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="leaveid")
	private long leaveId;
	
	@Column(name="empid")
	private long empid;
	
	@Column(name="leavetype")
	private String leaveType;
	
	@Column(name="start_Date")
	private Date startDate;
	
	@Column(name="end_date")
	private Date endDate;
	
	@Column(name="raised_by")
	private String raisedBy;
	
	@Column(name="num_of_days")
	private int numOfDays;
	
	@Column(name="leave_reason")
	private String reason;
	
	
	@Column(name="emp_active_status")
	private boolean empActiveStatus;
	
	@Column(name="last_updated_user")
	private String lastUpdatedUser;
	
	@Column(name="last_tx_id")
	private int lastTxId;
	
	@Column(name="approvedStatus")
	private String approvedStatus;
	
	@Column(name="applyDate")
	private LocalDate ApplyDate;
	
	@ManyToMany(cascade=CascadeType.ALL)
	@JoinColumn(name="empid")
	private Employee employee;
	
	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	public String getApprovedStatus() {
		return approvedStatus;
	}

	public void setApprovedStatus(String approvedStatus) {
		this.approvedStatus = approvedStatus;
	}

//	@ManyToMany(cascade=CascadeType.ALL)
//	@JoinColumn(name="leaveid")
//	Set<ApprovalStatus> approvalStatus=new HashSet<>();
//	
//	 @OneToMany(cascade = CascadeType.ALL)
//	 @JoinColumn(name="leaveid")
//	 private Set<ConditionMatrix> conditions;

	public boolean isEmpActiveStatus() {
		return empActiveStatus;
	}

	public void setEmpActiveStatus(boolean empActiveStatus) {
		this.empActiveStatus = empActiveStatus;
	}

	public String getLastUpdatedUser() {
		return lastUpdatedUser;
	}

	public void setLastUpdatedUser(String lastUpdatedUser) {
		this.lastUpdatedUser = lastUpdatedUser;
	}

	public int getLastTxId() {
		return lastTxId;
	}

	public void setLastTxId(int lastTxId) {
		this.lastTxId = lastTxId;
	}


	public long getLeaveId() {
		return leaveId;
	}

	public void setLeaveId(long leaveId) {
		this.leaveId = leaveId;
	}

	public long getEmpid() {
		return empid;
	}

	public void setEmpid(long empid) {
		this.empid = empid;
	}

	public String getLeaveType() {
		return leaveType;
	}

	public void setLeaveType(String leaveType) {
		this.leaveType = leaveType;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getRaisedBy() {
		return raisedBy;
	}

	public void setRaisedBy(String raisedBy) {
		this.raisedBy = raisedBy;
	}

	public int getNumOfDays() {
		return numOfDays;
	}

	public void setNumOfDays(int numOfDays) {
		this.numOfDays = numOfDays;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

//	public LocalDate getApplyDate() {
//		return ApplyDate.now();
//	}
//
//	public void setApplyDate(LocalDate applyDate) {
//		ApplyDate = applyDate.now();
//	}

	public LeaveTypeModel(long leaveId, long empid, String leaveType, Date startDate, Date endDate, String raisedBy,
			int numOfDays, String reason, boolean empActiveStatus, String lastUpdatedUser, int lastTxId,
			String approvedStatus, LocalDate applyDate) {
		super();
		this.leaveId = leaveId;
		this.empid = empid;
		this.leaveType = leaveType;
		this.startDate = startDate;
		this.endDate = endDate;
		this.raisedBy = raisedBy;
		this.numOfDays = numOfDays;
		this.reason = reason;
		this.empActiveStatus = empActiveStatus;
		this.lastUpdatedUser = lastUpdatedUser;
		this.lastTxId = lastTxId;
		this.approvedStatus = approvedStatus;
		ApplyDate = applyDate;
	}

	public LeaveTypeModel() {
		super();
	}

	

//	public LeaveTypeModel() {
//		super();
//	}

//	public Set<ApprovalStatus> getApprovalStatus() {
//		return approvalStatus;
//	}
//
//	public void setApprovalStatus(Set<ApprovalStatus> approvalStatus) {
//		this.approvalStatus = approvalStatus;
//	}
//
//	public LeaveTypeModel(Set<ApprovalStatus> approvalStatus) {
//		super();
//		this.approvalStatus = approvalStatus;
//	}
//
	

	

	
	
	

}
