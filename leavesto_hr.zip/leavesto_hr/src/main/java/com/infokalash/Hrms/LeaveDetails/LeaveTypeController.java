package com.infokalash.Hrms.LeaveDetails;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

//import com.infokalash.Hrms.LeaveDetails.LeaveTypeService.LeaveTypeService;
//import com.infokalash.Hrms.LeaveDetails.Model.LeaveTypeModel;
//import com.infokalash.Hrms.LeaveDetails.Repository.LeaveTypeRepository;

@RestController
@RequestMapping("/leave_type")
public class LeaveTypeController {
	
	@Autowired
	private LeaveTypeServiceImplementation leaveTypeService;
	
	@Autowired
	private LeaveTypeRepository leaveRepo;
	
//	@Autowired
//	 private EmailSenderService emailService;
	
	
	
	//method to create or insert new leavetype
	@PostMapping("/LeaveType")
	public ResponseEntity<String> create(@RequestBody LeaveTypeModel leave){
		
//		LeaveTypeModel leaveadd=leaveTypeService.insert(leave);
		
		// Send email to HR
	    
//	    String subject = "Leave Request ;
	    
//	    String body = "Employee " + leave.getEmpid() + " has requested a leave from " +
//	    		leave.getStartDate() + " to " + leave.getEndDate() + ". Please review and approve or deny the request.";
//		emailService.sendSimpleEmail("kurli.purnima@infokalash.com","This email is body","this email is subject");
	    
	    return ResponseEntity.ok("Leave request submitted successfully.");
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//method to get all the data from leave type
	@GetMapping("/showAllLeaves")
	public ResponseEntity<List<LeaveTypeModel>> get(){
		List<LeaveTypeModel> leave=leaveTypeService.getAllLeaves();
		return new ResponseEntity(leave,HttpStatus.OK);
	}
	
	//method to get the data using leave ID 
	@GetMapping("/{leaveId}")
	public ResponseEntity<Optional<LeaveTypeModel>> getById(@PathVariable Long leaveId){
		Optional<LeaveTypeModel> leaveid=leaveTypeService.getByleaveId(leaveId);
		return new ResponseEntity(leaveid,HttpStatus.OK);
	}
	
	//method to get the data using employee ID 
	@GetMapping("/getbyEmployeeId/{empid}")
	public ResponseEntity<List<LeaveTypeModel>> getLeaveTypeByEmployeeId(@PathVariable Long empid){
		List<LeaveTypeModel> leavetypebyempid=leaveTypeService.getLeaveByemployeeId(empid);
		return new ResponseEntity(leavetypebyempid,HttpStatus.OK);
	}
	
	//method to get the data using leavetype
	@GetMapping("/showByleaveType/{leaveType}")
	public ResponseEntity<List<LeaveTypeModel>>getByleaveType(@PathVariable String leaveType){
		List<LeaveTypeModel> leavetypes=leaveTypeService.getByLeaveType(leaveType);
		return new ResponseEntity(leavetypes,HttpStatus.OK);
		}
	
	//method to update the leave type model using leaveID
	@PutMapping("/updateLeave/{leaveId}")
	public ResponseEntity<LeaveTypeModel> updateById(@PathVariable Long leaveId,@RequestBody LeaveTypeModel leave){
		LeaveTypeModel leavetype=leaveTypeService.updateLeave(leaveId, leave);
		return new ResponseEntity(leavetype,HttpStatus.OK);	
	}
	
	//method to delete the leave type using leave ID
	@DeleteMapping("/deleteLeave/{leaveId}")
	public ResponseEntity<String> deleteById(@PathVariable Long leaveId){
		LeaveTypeModel deleteLeave=leaveRepo.findById(leaveId).orElseThrow();
		
		if(deleteLeave!=null) {
			leaveTypeService.deleteLeave(leaveId);
			return ResponseEntity.ok("deleted sucessfully");
		}else {
			return ResponseEntity.notFound().build();
		}
	}
	
	//method to search the leave type using employee id
	@GetMapping("/searchByempid/{empid}")
	public ResponseEntity<List<LeaveTypeModel>> searchBy(@PathVariable long empid){
		List<LeaveTypeModel> leave=leaveTypeService.findByempId(empid);
		if(leave!=null)
			return ResponseEntity.ok(leave);
		else
			return ResponseEntity.notFound().build();
	}
		
	
}
