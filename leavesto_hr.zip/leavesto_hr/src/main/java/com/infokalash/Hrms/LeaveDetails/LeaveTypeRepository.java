package com.infokalash.Hrms.LeaveDetails;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;


public interface LeaveTypeRepository extends JpaRepository<LeaveTypeModel,Long>{
	
	
	List<LeaveTypeModel> findByempid(Long empid);
	
	List<LeaveTypeModel> findByleaveType(String leavetype);
	
	List<LeaveTypeModel> searchByempid(Long empid);
}
