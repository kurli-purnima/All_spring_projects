package com.infokalash.crud;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class StudentController {
	
	//http://localhost:8080/student
	//to get the single data
	@GetMapping("/student")
	public Student getstudent() {
		return new Student("ramesh","h");
	}
	
	
	
	//http:localhost:8080/students
	//to get the multiple data
	@GetMapping("/students")
	public List<Student> getStudents(){
		List<Student> students = new ArrayList<>();
		students.add(new Student("ramesh","ku"));
		students.add(new Student("Thorn","ku"));
		students.add(new Student("Sufies","Cs"));
		students.add(new Student("Suresh","Ak"));
		students.add(new Student("Fakir","ku"));
		return students;
	}
	
	//http:localhost:8080/student/ramesh/fadtare
	//@PathVariable annotation
	@GetMapping("{firstName}/{lastName}")
	public Student studentPathvariake(@PathVariable("firstName") String firstName,@PathVariable("lastName") String lastName) {
		return new Student(firstName, lastName);
	}
	
	
	
	//build rest Api to handle query parameters
	//http://localhost:8080/student?firstName=ramesh&lastName=fadatare
	@GetMapping("/student/query")
	public Student studentQueryParam(@RequestParam(name="firstName") String firstName,@RequestParam(name="lastName") String lastName) {
		return new Student(firstName,lastName);
		
	}

}
