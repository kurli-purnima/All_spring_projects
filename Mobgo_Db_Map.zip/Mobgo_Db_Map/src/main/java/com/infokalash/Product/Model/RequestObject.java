//package com.infokalash.Product.Model;
//
//import java.util.Map;
//
//
//import org.springframework.data.mongodb.core.mapping.Document;
//
//
//
//@Document(collection = "mydb")
//public class RequestObject {
//	
//
////	private String id; 
//	
//    private Map<String, Object> data;
//
////	public String getId() {
////		return id;
////	}
////
////	public void setId(String id) {
////		this.id = id;
////	}
//
//	public Map<String, Object> getData() {
//		return data;
//	}
//
//	public void setData(Map<String, Object> data) {
//		this.data = data;
//	}
//
//    
//}
