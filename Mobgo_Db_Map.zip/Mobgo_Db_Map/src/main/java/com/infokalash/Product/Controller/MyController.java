package com.infokalash.Product.Controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.infokalash.Product.Repository.MyDataDao;
import com.infokalash.Product.Service.MyService;

@RestController
public class MyController {

	private final MyDataDao dao;
    private final MyService myService;

    @Autowired
    public MyController(MyService myService , MyDataDao dao) {
        this.myService = myService;
        this.dao= dao;
    }

    //insert the object
    @PostMapping("/processRequest")
    public ResponseEntity<String> processRequest(@RequestBody Map<String, Object> request) {
        myService.saveData(request);
        return ResponseEntity.ok("Data saved successfully!");
    }
    

    //retrive the data from database
    @GetMapping("/{id}")
    public Map<String, Object> getDataById(@PathVariable String id) {
        return myService.getDataById(id);
    }
    

    
    
}
