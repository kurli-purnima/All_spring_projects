package com.infokalash.Product.Service;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infokalash.Product.Repository.MyDataDao;


@Service
public class MyService {
	
	
    private final MyDataDao MyDatadao;

    @Autowired
    public MyService(MyDataDao MyDatadao) {
        this.MyDatadao = MyDatadao;
    }

    // Save the data to MongoDB using the repository
    public void saveData(Map<String, Object> data) {
    	
    	//Modifying the specific the attribute value
    	 Object specificValue = data.get("lastName");
         if (specificValue != null) {
             specificValue = "anil"; // Modify the specificValue here as needed
             data.put("lastName", specificValue);
              
    	MyDatadao.save(data);
    }
    
    }  

    //method to retrive data by Id from mongodb
    public Map<String, Object> getDataById(String id) {
        return MyDatadao.getDataById(id);
    }
    

}
