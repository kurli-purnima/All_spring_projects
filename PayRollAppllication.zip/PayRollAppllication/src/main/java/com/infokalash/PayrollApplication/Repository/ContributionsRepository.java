package com.infokalash.PayrollApplication.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infokalash.PayrollApplication.Model.Contributions;

public interface ContributionsRepository extends JpaRepository<Contributions,Long>{

}
