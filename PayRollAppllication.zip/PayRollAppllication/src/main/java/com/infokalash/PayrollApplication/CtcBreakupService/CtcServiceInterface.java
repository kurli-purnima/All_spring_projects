package com.infokalash.PayrollApplication.CtcBreakupService;

import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Service;

import com.infokalash.PayrollApplication.Model.CtcBreakup;



@Service
@Configuration
public interface CtcServiceInterface  {
	
	CtcBreakup create(CtcBreakup ctc);

}
