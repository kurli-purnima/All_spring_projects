package com.infokalash.PayrollApplication.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infokalash.PayrollApplication.Contributions.ContributionsServiceInterface;
import com.infokalash.PayrollApplication.Model.Contributions;

@RestController
@RequestMapping("/contribution")
public class ContributionsController {
	
	@Autowired
	private ContributionsServiceInterface service;
	
	@PostMapping("/addContributions")
	public ResponseEntity<Contributions> createContributions(@RequestBody Contributions contibution){
		Contributions con=service.createContributions(contibution);
		return new ResponseEntity<>(con,HttpStatus.OK);
	}

}
