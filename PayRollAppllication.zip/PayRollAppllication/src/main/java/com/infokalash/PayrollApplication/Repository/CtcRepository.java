package com.infokalash.PayrollApplication.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.infokalash.PayrollApplication.Model.CtcBreakup;


@Repository
public interface CtcRepository extends JpaRepository<CtcBreakup,Long> {

}
