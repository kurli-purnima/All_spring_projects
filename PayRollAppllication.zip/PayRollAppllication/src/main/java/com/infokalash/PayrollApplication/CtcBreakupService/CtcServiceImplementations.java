package com.infokalash.PayrollApplication.CtcBreakupService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.infokalash.PayrollApplication.Model.Contributions;
import com.infokalash.PayrollApplication.Model.CtcBreakup;
import com.infokalash.PayrollApplication.Repository.ContributionsRepository;
import com.infokalash.PayrollApplication.Repository.CtcRepository;


@Service
public class CtcServiceImplementations implements CtcServiceInterface{
	@Autowired
	private CtcRepository repo;
	
	@Autowired
	private ContributionsRepository conrepo;
	
	@Value("${foodAllowance:default value}")
	private double foodallowance;
	

	
	@Override
	public CtcBreakup create(CtcBreakup ctc) {
		// TODO Auto-generated method stub
		
		Contributions con=new Contributions();
		

		double monthlyCtc=ctc.getAnnualCtc()/12;
		ctc.setMonthlyCtc(monthlyCtc);
		
		double basicSalary=monthlyCtc*40/100;
		ctc.setBasicSalary(basicSalary);
		
		ctc.setFoodAllowance(foodallowance);
		
		ctc.setConveyanceAllowance(1000);
		
		ctc.setMedicalAllowance(1000);

		ctc.setInternetAllowance(500);
		
		ctc.setSpecialAllowance(0);
		
		double Hra = basicSalary*20/100;
		ctc.setHouseRentAllowance(Hra);
		
		
		double grossSalary=basicSalary+Hra+foodallowance
		+ctc.getConveyanceAllowance()+ctc.getMedicalAllowance()+ctc.getInternetAllowance();
		ctc.setGrossSalary(grossSalary);
		
		
		con.setEmployer_Epf(basicSalary*13/100);
		con.setEmployer_Esic(grossSalary*3.25/100);
		con.setTotalEmployerContributions(con.getEmployer_Epf()+con.getEmployer_Esic());
		
		con.setEmployee_Epf(basicSalary*12/100);
		con.setEmployee_Esic(Math.round(grossSalary*0.75/100));
		
		double totalcontribution=con.getEmployee_Epf()+con.getEmployee_Esic();
		con.setTotalEmployeeContributions(Math.round(totalcontribution));
		
	
		ctc.setInHandSalary(grossSalary-con.getTotalEmployeeContributions());
		
		return repo.save(ctc); 
	}
	
	

	

	
}
