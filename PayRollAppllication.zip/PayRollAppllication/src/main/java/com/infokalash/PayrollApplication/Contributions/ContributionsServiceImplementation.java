package com.infokalash.PayrollApplication.Contributions;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infokalash.PayrollApplication.Model.Contributions;
import com.infokalash.PayrollApplication.Repository.ContributionsRepository;

@Service
public class ContributionsServiceImplementation implements ContributionsServiceInterface{
	
	@Autowired
	private ContributionsRepository repo;

	@Override
	public Contributions createContributions(Contributions con) {
		Contributions addCon=repo.save(con);
		return addCon;
	}

	
}
