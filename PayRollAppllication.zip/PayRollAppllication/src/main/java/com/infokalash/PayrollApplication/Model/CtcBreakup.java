package com.infokalash.PayrollApplication.Model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ctc")
public class CtcBreakup {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id;
	
	@Column(name="empid")
	private long empid;
	
	@Column(name="annual_ctc")
	private double annualCtc;
	
	@Column(name="monthlyCtc")
	private double monthlyCtc;
	
	@Column(name="basicSalary")
	private double basicSalary;
	
	@Column(name="HRA")
	private double HouseRentAllowance;
	
	@Column(name="foodAllowance")
	private double foodAllowance;
	
	@Column(name="conveyanceAlllowance")
	private double conveyanceAllowance;
	
	@Column(name="medicalAllowance")
	private double medicalAllowance;
	
	@Column(name="internetAllowance")
	private double InternetAllowance;
	
	@Column(name="spl_allowance")
	private double specialAllowance;
	
	@Column(name="grossSalary")
	private double grossSalary;
	
	@Column(name="inhandsalary")
	private double inHandSalary;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getEmpid() {
		return empid;
	}

	public void setEmpid(long empid) {
		this.empid = empid;
	}

	public double getAnnualCtc() {
		return annualCtc;
	}

	public void setAnnualCtc(double annualCtc) {
		this.annualCtc = annualCtc;
	}

	public double getMonthlyCtc() {
		return monthlyCtc;
	}

	public void setMonthlyCtc(double monthlyCtc) {
		this.monthlyCtc = monthlyCtc;
	}

	public double getBasicSalary() {
		return basicSalary;
	}

	public void setBasicSalary(double basicSalary) {
		this.basicSalary = basicSalary;
	}

	public double getHouseRentAllowance() {
		return HouseRentAllowance;
	}

	public void setHouseRentAllowance(double houseRentAllowance) {
		HouseRentAllowance = houseRentAllowance;
	}

	public double getFoodAllowance() {
		return foodAllowance;
	}

	public void setFoodAllowance(double foodAllowance) {
		this.foodAllowance = foodAllowance;
	}

	public double getConveyanceAllowance() {
		return conveyanceAllowance;
	}

	public void setConveyanceAllowance(double conveyanceAllowance) {
		this.conveyanceAllowance = conveyanceAllowance;
	}

	public double getMedicalAllowance() {
		return medicalAllowance;
	}

	public void setMedicalAllowance(double medicalAllowance) {
		this.medicalAllowance = medicalAllowance;
	}

	public double getInternetAllowance() {
		return InternetAllowance;
	}

	public void setInternetAllowance(double internetAllowance) {
		InternetAllowance = internetAllowance;
	}

	public double getSpecialAllowance() {
		return specialAllowance;
	}

	public void setSpecialAllowance(double specialAllowance) {
		this.specialAllowance = specialAllowance;
	}

	public double getGrossSalary() {
		return grossSalary;
	}

	public void setGrossSalary(double grossSalary) {
		this.grossSalary = grossSalary;
	}


	public double getInHandSalary() {
		return inHandSalary;
	}

	public void setInHandSalary(double inHandSalary) {
		this.inHandSalary = inHandSalary;
	}

	public CtcBreakup(long id, long empid, double annualCtc, double monthlyCtc, double basicSalary,
			double houseRentAllowance, double foodAllowance, double conveyanceAllowance, double medicalAllowance,
			double internetAllowance, double specialAllowance, double grossSalary, double inHandSalary) {
		super();
		this.id = id;
		this.empid = empid;
		this.annualCtc = annualCtc;
		this.monthlyCtc = monthlyCtc;
		this.basicSalary = basicSalary;
		HouseRentAllowance = houseRentAllowance;
		this.foodAllowance = foodAllowance;
		this.conveyanceAllowance = conveyanceAllowance;
		this.medicalAllowance = medicalAllowance;
		InternetAllowance = internetAllowance;
		this.specialAllowance = specialAllowance;
		this.grossSalary = grossSalary;
		this.inHandSalary = inHandSalary;
	}

	public CtcBreakup() {
		super();
	}

	

}
