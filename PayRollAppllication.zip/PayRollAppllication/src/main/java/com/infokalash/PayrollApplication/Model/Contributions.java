package com.infokalash.PayrollApplication.Model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="contributions")
public class Contributions {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id;
	
	@Column(name="employer_epf")
	private double employer_Epf;
	
	@Column(name="employer_esic")
	private double employer_Esic;
	
	@Column(name="total_employer_contributions")
	private double totalEmployerContributions;
	
	@Column(name="employee_epf")
	private double employee_Epf;
	
	@Column(name="employee_esic")
	private double employee_Esic;
	
	@Column(name="total_employee_contribution")
	private double totalEmployeeContributions;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public double getEmployer_Epf() {
		return employer_Epf;
	}

	public void setEmployer_Epf(double employer_Epf) {
		this.employer_Epf = employer_Epf;
	}

	public double getEmployer_Esic() {
		return employer_Esic;
	}

	public void setEmployer_Esic(double employer_Esic) {
		this.employer_Esic = employer_Esic;
	}

	public double getTotalEmployerContributions() {
		return totalEmployerContributions;
	}

	public void setTotalEmployerContributions(double totalEmployerContributions) {
		this.totalEmployerContributions = totalEmployerContributions;
	}

	public double getEmployee_Epf() {
		return employee_Epf;
	}

	public void setEmployee_Epf(double employee_Epf) {
		this.employee_Epf = employee_Epf;
	}

	public double getEmployee_Esic() {
		return employee_Esic;
	}

	public void setEmployee_Esic(double employee_Esic) {
		this.employee_Esic = employee_Esic;
	}

	public double getTotalEmployeeContributions() {
		return totalEmployeeContributions;
	}

	public void setTotalEmployeeContributions(double totalEmployeeContributions) {
		this.totalEmployeeContributions = totalEmployeeContributions;
	}

	public Contributions(long id, double employer_Epf, double employer_Esic, double totalEmployerContributions,
			double employee_Epf, double employee_Esic, double totalEmployeeContributions) {
		super();
		this.id = id;
		this.employer_Epf = employer_Epf;
		this.employer_Esic = employer_Esic;
		this.totalEmployerContributions = totalEmployerContributions;
		this.employee_Epf = employee_Epf;
		this.employee_Esic = employee_Esic;
		this.totalEmployeeContributions = totalEmployeeContributions;
	}

	public Contributions() {
		super();
	}
	
	
	

}
