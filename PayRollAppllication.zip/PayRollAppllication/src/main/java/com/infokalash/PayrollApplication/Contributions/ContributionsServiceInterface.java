package com.infokalash.PayrollApplication.Contributions;

import org.springframework.stereotype.Service;

import com.infokalash.PayrollApplication.Model.Contributions;

@Service
public interface ContributionsServiceInterface {
	
	Contributions createContributions(Contributions con);

}
