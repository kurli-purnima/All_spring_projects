package com.infokalash.Hrms.CTC.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;

import com.infokalash.Hrms.CTC.Repository.MyDataDao;


@Service
public class MyService {
	
	
    private final MyDataDao MyDatadao;

    @Autowired
    public MyService(MyDataDao MyDatadao) {
        this.MyDatadao = MyDatadao;
    }
    
    @Autowired
    public MongoTemplate mongoTemplate;

    
    
    public void storeData(Map<String, Object> jsonData) {
        for (Map.Entry<String, Object> entry : jsonData.entrySet()) {
            saveData(entry.getKey(), entry.getValue());
        }
    }

    private void saveData(String objectType, Object value) {
        String collectionName = objectType + "Collection";
        if (value instanceof Map) {
            Map<String, Object> objectData = (Map<String, Object>) value;
            mongoTemplate.insert(objectData, collectionName);
        } else if (value instanceof List) {
            List<Map<String, Object>> listData = (List<Map<String, Object>>) value;
            for (int i = 0; i < listData.size(); i++) {
                mongoTemplate.insert(listData.get(i), collectionName);
            }
        } else {
            Map<String, Object> data = new HashMap<>();
            data.put("value", value);
            mongoTemplate.insert(data, collectionName);
        }
    	 
    }
    
     
    
    
    
    
    
    
    
    
    
    
    
    
    

//    // Save the data to MongoDB using the repository
//    public void saveData(Map<String, Object> data) {
//    	
//    	//Modifying the specific the attribute value
////    	 Object specificValue = data.get("lastName");
////         if (specificValue != null) {
////             specificValue = "anil"; // Modify the specificValue here as needed
////             data.put("lastName", specificValue);
////             
//    	MyDatadao.save(data);
//    }
//    
    
    

    //method to retrive data by Id from mongodb
    public Map<String, Object> getDataById(String id) {
        return MyDatadao.getDataById(id);
    }
    

}
