package com.infokalash.Hrms.CTC;

import org.springframework.boot.Banner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class Generic1Application {

	public static void main(String[] args) {
		SpringApplication.run(Generic1Application.class, args);
	}
	@Bean
    public Banner customBanner() {
        return (environment, sourceClass, out) -> {
            out.println("*******************************************");
            out.println("*                                         *");
            out.println("*  Welcome to My Custom Spring Boot App!  *");
            out.println("*                                         *");
            out.println("*******************************************");
        };
    }

}
