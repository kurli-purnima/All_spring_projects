package com.infokalash.Hrms.CTC.Repository;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.management.Query;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.convert.MappingMongoConverter;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Component;


@Configuration
public class MyDataDao {

    private final MongoTemplate mongoTemplate;

    @Autowired
    public MyDataDao(MongoTemplate mongoTemplate) {
        this.mongoTemplate = mongoTemplate;
    }


    //method to Store The data to mongodb database
	public Map<String, Object> save(Map<String, Object> data) {
		return mongoTemplate.save(data,"mydb");
	   
	}
	
	//method to retrive data from database
	public Map<String, Object> getDataById(String id) {
		 ObjectId objectId = new ObjectId(id);
		 return mongoTemplate.findById(objectId, Map.class, "mydb"); 
	}
	
	
}

