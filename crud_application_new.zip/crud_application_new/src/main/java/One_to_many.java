
public class One_to_many {
	
	private Integer person_id;
	private String name;
	private Integer age;
	private String Gender;
	private Integer phone_number;
	
	
	public Person(Integer )
}
