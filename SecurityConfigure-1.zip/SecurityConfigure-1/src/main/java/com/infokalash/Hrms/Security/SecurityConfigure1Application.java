package com.infokalash.Hrms.Security;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecurityConfigure1Application {

	public static void main(String[] args) {
		SpringApplication.run(SecurityConfigure1Application.class, args);
	}

}
