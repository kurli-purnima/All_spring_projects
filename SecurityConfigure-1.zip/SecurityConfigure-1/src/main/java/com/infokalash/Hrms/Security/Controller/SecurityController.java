package com.infokalash.Hrms.Security.Controller;

import java.security.Principal;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class SecurityController {
	
	 @GetMapping("/")
	 public String home() {
	        return "home";
	    }

	 @GetMapping("/login")
	 public String login() {
	        return "login";
	    }
	 
	 @GetMapping("/user")
	 public Principal user(Principal principal) {
		 System.out.println("username"+ principal.getName());
		 return principal;
	 }

}
