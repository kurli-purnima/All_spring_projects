package com.infokalash.Hrms.Security;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConfigSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
