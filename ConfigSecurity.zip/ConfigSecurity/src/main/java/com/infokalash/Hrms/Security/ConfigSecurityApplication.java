package com.infokalash.Hrms.Security;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConfigSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConfigSecurityApplication.class, args);
	}

}
