package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.demo.model.Employee;
import com.example.demo.repository.EmployeeRepository;
import java.util.List;
import java.util.Optional;

@Service
public class EmployeeService {

        @Autowired
            EmployeeRepository empRepository;        
     
        @RequestMapping(value="/login", method=RequestMethod.POST)
        public Employee createEmployee1(@RequestBody Employee emp) {
            EmployeeService empService = null;
			return empService.createEmployee1(emp);
        }
        
        // CREATE 
        public Employee createEmployee(Employee emp) {
            return empRepository.save(emp);
        }

        // READ
        public List<Employee> getEmployees() {
            return empRepository.findAll();
        }

        // DELETE
        public void deleteEmployee(Long empId) {
            empRepository.deleteById(empId);
        }
        
     // UPDATE
        public Employee updateEmployee(Long empId, Employee employeeDetails) {
                Optional<Employee> updatedEmployee = empRepository.findById(empId);
                if(updatedEmployee.isPresent()) {
                	
                	
               // }
               // Employee updatedEmployee = new Employee();
                //System.out.println(emp.get(0));
                
               // if(!emp.isEmpty()) {                	
                	
                	updatedEmployee.get().setFirstName(employeeDetails.getFirstName());
                    updatedEmployee.get().setLastName(employeeDetails.getLastName());
                    updatedEmployee.get().setEmailId(employeeDetails.getEmailId());
                //}
                }
                
                return empRepository.save(updatedEmployee);                                
        }
}


