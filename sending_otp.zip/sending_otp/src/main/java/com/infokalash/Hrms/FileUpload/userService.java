package com.infokalash.Hrms.FileUpload;

import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class userService {
	@Autowired
	private userRepo repo;
	
	

	public int send(user us) {
		// TODO Auto-generated method stub
		Random ran=new Random();
		int randnum=ran.nextInt();
		return randnum;
	}

}
