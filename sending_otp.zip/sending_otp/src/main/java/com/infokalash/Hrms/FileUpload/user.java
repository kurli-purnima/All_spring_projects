package com.infokalash.Hrms.FileUpload;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="usertab")
public class user {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id;
	
	@Column(name="mobile")
	private int mobile;
	
	@Column(name="otp")
	private int otp;


	public int getOtp() {
		return otp;
	}

	public void setOtp(int otp) {
		this.otp = otp;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public int getMobile() {
		return mobile;
	}

	public void setMobile(int mobile) {
		this.mobile = mobile;
	}

	public user(long id, int mobile, int otp) {
		super();
		this.id = id;
		this.mobile = mobile;
		this.otp = otp;
	}

	public user() {
		super();
	}

	
	
	

}
