package com.infokalash.Hrms.FileUpload;

import org.springframework.data.jpa.repository.JpaRepository;

public interface userRepo extends JpaRepository<user,Integer> {

}
