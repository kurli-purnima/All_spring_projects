package com.infokalash.Hrms.CTC.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.infokalash.Hrms.CTC.Model.Payslip;
import com.infokalash.Hrms.CTC.repository.PayslipRepository;

@Service
public class PayslipService {
    private final PayslipRepository payslipRepository;

    public PayslipService(PayslipRepository payslipRepository) {
        this.payslipRepository = payslipRepository;
    }

    public Payslip getEmployeePayslips(Long employeeId) {
        return payslipRepository.findByEmployeeId(employeeId);
    }
}
