package com.infokalash.Hrms.CTC.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.infokalash.Hrms.CTC.Model.Payslip;

@Repository
public interface PayslipRepository extends JpaRepository<Payslip, Long> {
	
    Payslip findByEmployeeId(Long employeeId);
}
