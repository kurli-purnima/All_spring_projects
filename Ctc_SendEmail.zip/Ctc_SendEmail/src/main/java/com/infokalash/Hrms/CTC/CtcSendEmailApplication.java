package com.infokalash.Hrms.CTC;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CtcSendEmailApplication {

	public static void main(String[] args) {
		SpringApplication.run(CtcSendEmailApplication.class, args);
	}

}
