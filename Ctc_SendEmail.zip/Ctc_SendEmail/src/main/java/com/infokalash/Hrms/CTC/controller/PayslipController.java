package com.infokalash.Hrms.CTC.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infokalash.Hrms.CTC.Model.Payslip;
import com.infokalash.Hrms.CTC.service.PayslipService;

@RestController
@RequestMapping("/payslip")
public class PayslipController {
    private final PayslipService payslipService;

    public PayslipController(PayslipService payslipService) {
        this.payslipService = payslipService;
    }

    @GetMapping("/{employeeId}")
    public ResponseEntity<Payslip> getEmployeePayslips(@PathVariable Long employeeId) {
        Payslip payslips = payslipService.getEmployeePayslips(employeeId);
        return ResponseEntity.ok(payslips);
    }
}
