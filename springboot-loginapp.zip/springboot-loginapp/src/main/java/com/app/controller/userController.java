package com.app.controller;


import javax.persistence.PostLoad;

import org.springframework.boot.autoconfigure.security.SecurityProperties.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.app.entity.user;



@Controller
public class userController {
	
	@GetMapping("/login")
	public String login(Model model) {
	User user = new User();
		model.addAttribute("user",user);
		return "login";
	}
	
	@PostMapping("/userLogin")
	public String loginUser(@ModelAttribute("user") User user) {
	System.out.println(user.getName());
		
		System.out.println(user.getPassword());
		return "home";
	}
	

}
