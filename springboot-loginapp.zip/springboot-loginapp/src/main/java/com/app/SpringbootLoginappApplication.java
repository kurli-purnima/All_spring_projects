package com.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootLoginappApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootLoginappApplication.class, args);
		
		System.out.println(" My application is running properly................");
	}

}
