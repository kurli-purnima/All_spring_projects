package JDBC;

import javax.persistence.Entity;

@Entity
public class One_to_many {
	
	
	private int person_id;
	private String Name;
	private int Age;
	private String Gender;
	private int phone_number;

}
