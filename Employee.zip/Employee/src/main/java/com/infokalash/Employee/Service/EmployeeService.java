package com.infokalash.Employee.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.infokalash.Employee.Model.Employee;
import com.infokalash.Employee.Repository.EmployeeRepository;

@Service
public class EmployeeService {

	@Autowired
	private EmployeeRepository employeeRepo;
	
	 public Employee createEmployee(Employee employee) {
		 return employeeRepo.save(employee);
	    }
	 

}
